To play the game, open the Box Shooter.html file in firefox or microsoft edge (Chrome doesnt work)





W,A,S,D - move
Mouse button1 - shoot

Your goal is to get the highest score possible by shooting different boxes.

Green - +5 points
Yellow - -3 seconds
White - +3 seconds
Purple - Everything is possible!!!